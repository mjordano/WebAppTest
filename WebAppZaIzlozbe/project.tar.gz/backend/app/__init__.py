"""
App paket - inicijalizacija
"""
