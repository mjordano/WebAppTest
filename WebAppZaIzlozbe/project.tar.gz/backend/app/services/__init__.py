"""
Services paket - poslovne logike servisa
"""
