"""
Utils paket - pomoćne funkcije
"""
